
import photo1 from './assets/avto-him.png'
import photo2 from './assets/avto-him1.png'
import photo3 from './assets/dezinfect1.png'
import photo4 from './assets/bit-him.png'
import photo5 from './assets/bit-him1.png'
import photo6 from './assets/dezinfect.png'

export const productionData = [
  {
    id: 1,
    image: photo1,
    title: 'Автомобильная химия',
    description: 'Безусловно, сплоченность команды профессионалов позволяет оценить значение форм воздействия.'
  },
  {
    id: 2,
    image: photo2,
    title: 'Бытовая химия',
    description: 'А также стремищиеся вытеснить традиционное производство, нанотехнологии функционально разнесены на независимые элементы.'
  },
  {
    id: 3,
    image: photo3,
    title: 'Дезинфицирующие средства',
    description: 'Лишь интерактивные прототипы призваны к ответу.'
  },
  {
    id: 4,
    image: photo4,
    title: 'Пищевые аэрозоли',
    description: 'Безусловно, сплоченность команды профессионалов позволяет оценить значение форм воздействия.'
  },
  {
    id: 5,
    image: photo5,
    title: 'Косметическая продукция',
    description: 'Лишь интерактивные прототипы призваны к ответу.'
  },
  {
    id: 6,
    image: photo6,
    title: 'Краски аэрозольные',
    description: 'А также стремищиеся вытеснить традиционное производство, нанотехнологии функционально разнесены на независимые элементы.'
  }
];