import { useState } from 'react'
import photo1 from '../assets/01.png'
import photo2 from '../assets/011.png'
import photo3 from '../assets/012.png'
import photo4 from '../assets/013.png'
import './section1.css'
export default function Section1() {
  const [count, setCount] = useState(0)

return (<>
  <section className='work-scheme'>
    <div className='container'>
      <div className='title-section'>
        <div className='blue-line'></div>
        <h1>СХЕМА РАБОТЫ</h1>
      </div>
      <div className='scheme-items'>
        <div className='scheme-item'>
          <div className='item-header'>
            <img src={photo1} alt='01' className='step-image' />
            <h2>Знакомство</h2>
          </div>
          <p>Безусловно, сплоченность команды профессионалов позволяет оценить значение форм воздействия.</p>
          <link className='blue-link'>Оставить заявку</link>
        </div>
        <div className='scheme-item'>
          <div className='item-header'>
            <img src={photo2} alt='02' className='step-image' />
            <h2>Заключение договора</h2>
          </div>
          <p>Лишь интерактивные прототипы призваны к ответу.</p>
        </div>
        <div className='scheme-item'>
          <div className='item-header'>
            <img src={photo3} alt='03' className='step-image' />
            <h2>Производство</h2>
          </div>
          <p>А также стремящиеся вытеснить традиционное производство, многохолодная функционально разнесены на независимые элементы.</p>
        </div>
        <div className='scheme-item'>
          <div className='item-header'>
            <img src={photo4} alt='04' className='step-image' />
            <h2>Доставка</h2>
          </div>
          <p>В частности, экономическая повестка сегодняшнего дня говорит о возможностях приоритетации разума над эмоциями.</p>
        </div>
      </div>
    </div>
  </section>
</>
  )
}