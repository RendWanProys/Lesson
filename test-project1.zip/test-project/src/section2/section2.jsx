import { useState } from 'react'
import './section2.css'
import { productionData } from '../productionData.js' 

export default function Section2() {
  const [count, setCount] = useState(0)
  return (
    <>
      <section className='contract-production'>
        <div className='container'>
          <h1>КОНТРАКТНОЕ ПРОИЗВОДСТВО</h1>
          <div className='production-grid'>
            {productionData.map(item => (
              <div key={item.id} className='production-item'>
                <div className='item-content'>
                  <div className='text-part'>
                    <h2>{item.title}</h2>
                    <p>{item.description}</p>
                  </div>
                  <div className='image-part'>
                    <img src={item.image} alt={item.title} />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  )
}