import { useState } from 'react' 
import './App.css'
import Section1 from './section1/section1'
import Section2 from './section2/section2'
export default function App() { 
  const [count, setCount] = useState(0) 

  return (
    <>
      <Section1 />
      <Section2 />
    </>
  )
}
