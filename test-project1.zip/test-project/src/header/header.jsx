import { useState } from 'react'
import './header.css'
import photo1 from '../assets/logo.png'
import photo2 from '../assets/phone.png'

function Header() {
  const [count, setCount] = useState(0)

  return (
  <>
  <header>
    <nav>
      <div className='leftnav'>
      <div className='photo1div'><img src={photo1} className='photo1' /></div>
      <ul>
        <li>О компании</li>
        <li>Контрактное производство</li>
        <li>Собственные торговые марки</li>
        <li>Новости</li>
        <li>Контакты</li>
      </ul></div>
      <div className='rightnav'>
        <img src={photo2} className='photo2'/>
        <p>89506708570</p>
        <button className='headerverh'>Получить консультацию</button>
      </div>
    </nav>
    <div className='nave'>
      <div className='prevu'>
        <h1>Комплексное обеспечение товарами <br />и расходными материалами бизнеса</h1>
        <p>Высокий уровень вовлечения представителей целевой аудитории является четким <br />доказательством простого факта: высококачественный прототип будущего проекта <br />напрямую зависит от анализа существующих паттернов поведения.</p>
        <button className='headerverh'>Подробнее о компании</button>
      </div>
      <div className='niznave'>
        
      </div>
    </div>
  </header>
  </>
  )
}
export default Header