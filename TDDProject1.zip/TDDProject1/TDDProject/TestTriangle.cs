﻿using TDDProject;

namespace TDDProject
{
    [TestClass]
    public class TestTemperature
    {
        ///<summary>
        ///Позитивный тест
        ///Конвертация в Фаренгейты - ноль градусов
        ///</summary>
        [TestMethod]
        public void ConvertToFahrenheit_ZeroCelsius()
        {
            Temperature temp = new Temperature(0);
            Assert.AreEqual(32.0, temp.ConvertToFahrenheit());
        }

        ///<summary>
        ///Позитивный тест
        ///Конвертация в Фаренгейты - точка кипения воды
        ///</summary>
        [TestMethod]
        public void ConvertToFahrenheit_BoilingPoint()
        {
            Temperature temp = new Temperature(100);
            Assert.AreEqual(212.0, temp.ConvertToFahrenheit());
        }

        ///<summary>
        ///Позитивный тест
        ///Конвертация в Фаренгейты - отрицательная температура
        ///</summary>
        [TestMethod]
        public void ConvertToFahrenheit_NegativeTemperature()
        {
            Temperature temp = new Temperature(-40);
            Assert.AreEqual(-40.0, temp.ConvertToFahrenheit());
        }

        ///<summary>
        ///Позитивный тест
        ///Конвертация в Кельвины - ноль градусов
        ///</summary>
        [TestMethod]
        public void ConvertToKelvin_ZeroCelsius()
        {
            Temperature temp = new Temperature(0);
            Assert.AreEqual(273.15, temp.ConvertToKelvin());
        }

        ///<summary>
        ///Позитивный тест
        ///Конвертация в Кельвины - положительная температура
        ///</summary>
        [TestMethod]
        public void ConvertToKelvin_PositiveTemperature()
        {
            Temperature temp = new Temperature(25);
            Assert.AreEqual(298.15, temp.ConvertToKelvin());
        }
        ///<summary>
        ///Позитивный тест
        ///Конвертация в Кельвины - абсолютный ноль
        ///</summary>
        [TestMethod]
        public void ConvertToKelvin_AbsoluteZero()
        {
            Temperature temp = new Temperature(-273.15);
            Assert.AreEqual(0.0, temp.ConvertToKelvin());
        }
        ///<summary>
        ///Позитивный тест
        ///Конвертация в Кельвины - ниже абсолютного нуля
        ///</summary>
        [TestMethod]
        public void ConvertToKelvin_BelowAbsoluteZero()
        {
            Temperature temp = new Temperature(-300);
            Assert.AreEqual(0.0, temp.ConvertToKelvin());
        }
        ///<summary>
        ///Позитивный тест
        ///Конвертация в Реомюры - ноль градусов
        ///</summary>
        [TestMethod]
        public void ConvertToReaumur_ZeroCelsius()
        {
            Temperature temp = new Temperature(0);
            Assert.AreEqual(0.0, temp.ConvertToReaumur());
        }
        ///<summary>
        ///Позитивный тест
        ///Конвертация в Реомюры - положительная температура
        [TestMethod]
        public void ConvertToReaumur_PositiveTemperature()
        {
            Temperature temp = new Temperature(100);
            Assert.AreEqual(80.0, temp.ConvertToReaumur());
        }
        ///<summary>
        ///Позитивный тест
        ///Конвертация в Реомюры - отрицательная температура
        [TestMethod]
        public void ConvertToReaumur_NegativeTemperature()
        {
            Temperature temp = new Temperature(-40);
            Assert.AreEqual(-32.0, temp.ConvertToReaumur());
        }
        ///<summary>
        ///Позитивный тест
        ///Получение значения в Цельсиях
        [TestMethod]
        public void CelsiusProperty_ReturnsCorrectValue()
        {
            Temperature temp = new Temperature(37.5);
            Assert.AreEqual(37.5, temp.Celsius);
        }
        ///<summary>
        ///Позитивный тест
        ///Температура тела человека
        [TestMethod]
        public void ConvertToFahrenheit_HumanBodyTemperature()
        {
            Temperature temp = new Temperature(37);
            Assert.AreEqual(98.6, temp.ConvertToFahrenheit(), 0.01);
        }
        ///<summary>
        ///Позитивный тест
        ///Комнатная температура в Кельвинах
        [TestMethod]
        public void ConvertToKelvin_RoomTemperature()
        {
            Temperature temp = new Temperature(20);
            Assert.AreEqual(293.15, temp.ConvertToKelvin());
        }
        ///<summary>
        ///Позитивный тест
        ///Температура замерзания воды в Реомюрах
        [TestMethod]
        public void ConvertToReaumur_FreezingPoint()
        {
            Temperature temp = new Temperature(0);
            Assert.AreEqual(0.0, temp.ConvertToReaumur());
        }
    }
}
