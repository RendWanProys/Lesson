﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TDDProject
{
    public class Temperature
    {
        private double _celsius;

        public Temperature(double celsius)
        {
            _celsius = celsius;
        }
        public double Celsius
        {
            get { return _celsius; }
        }
        public double ConvertToFahrenheit()
        {
            return (_celsius * 9 / 5) + 32;
        }

        public double ConvertToKelvin()
        {
            double kelvin = _celsius + 273.15;
            if (kelvin < 0)
            {
                return 0;
            }
            else
            {
                return kelvin;
            }
        }

        public double ConvertToReaumur()
        {
            return _celsius * 4 / 5;
        }
    }
}




